//45
//4546
//454647
//45464748
//4546474849
#include<stdio.h>

main()
{
	
	int i,j;
	
	for(i=45;i<=49;i++)
	{

		for(j=45;j<=i;j++)
		{
			printf("%d",j);	
		}
			printf("\n");
	}
}
